package factory.Sorters_and_Lists;

import sortingservice.PriorityQueue;

import java.util.Comparator;
import java.util.Iterator;
import java.util.NoSuchElementException;

public class PriorityQ<T> implements PriorityQueue<T> {
    private TreeNode<T> root; // The root node of the heap
    private final Comparator<T> comparator; // The comparator used for ordering the heap
    private int size = 0; // The number of elements in the heap

    // Constructor for creating a priority queue with a custom comparator
    public PriorityQ(Comparator<T> comparator) {
        this.comparator = comparator;
    }

    // Checks if the priority queue is empty
    public boolean isEmpty() {
        return size == 0;
    }


    /**
     * Inserts a new element into the heap.
     *
     * @param value the value to insert
     */
    public void insert(T value) {
        if (root == null) {
            root = new TreeNode<>(value, null); // If heap is empty, insert at root
        } else {
            // Find the correct place to insert the new node
            TreeNode<T> node = root;
            // Use the binary representation of size+1 to find the insertion point
            String path = Integer.toBinaryString(++size).substring(1);

            for (char direction : path.toCharArray()) {
                if (direction == '1') {
                    if (node.right == null) {
                        node.right = new TreeNode<>(value, node);
                        heapify(node.right); // Restore heap property after insertion
                        return;
                    }
                    node = node.right;
                } else {
                    if (node.left == null) {
                        node.left = new TreeNode<>(value, node);
                        heapify(node.left); // Restore heap property after insertion
                        return;
                    }
                    node = node.left;
                }
            }
        }
        size++;
    }

    /**
     * Removes and returns the root element from the heap.
     *
     * @return the minimum element in the heap
     */
    public T remove() {
        if (isEmpty()) {
            throw new NoSuchElementException("Priority queue is empty");
        }
        T value = root.value;
        if (size == 1) {
            root = null;
        } else {
            // Find the last node and use it to replace the root
            TreeNode<T> node = root;
            String path = Integer.toBinaryString(size).substring(1); // Binary representation of the size
            for (char direction : path.toCharArray()) {
                node = direction == '1' ? node.right : node.left;
            }

            // Move the last node to the root and remove the last node
            if (path.charAt(path.length() - 1) == '1') {
                node.parent.right = null;
            } else {
                node.parent.left = null;
            }

            root.value = node.value;
            heapifyDown(root); // Restore heap property after removal
        }
        size--;
        return value;
    }

    // Helper method to restore the heap property from a node up to the root
    private void heapify(TreeNode<T> node) {
        while (node.parent != null && comparator.compare(node.value, node.parent.value) < 0) {
            swap(node, node.parent);
            node = node.parent;
        }
    }

    // Returns the number of elements in the priority queue
    public long size() {
        return size;
    }


    // Helper method to restore the heap property by moving a node down the tree
    private void heapifyDown(TreeNode<T> node) {
        while (node.left != null) {
            TreeNode<T> smallerChild = node.left;
            if (node.right != null && comparator.compare(node.right.value, node.left.value) < 0) {
                smallerChild = node.right;
            }
            if (comparator.compare(node.value, smallerChild.value) > 0) {
                swap(node, smallerChild);
                node = smallerChild;
            } else {
                break;
            }
        }
    }

    // Swap the values of two nodes
    private void swap(TreeNode<T> a, TreeNode<T> b) {
        T temp = a.value;
        a.value = b.value;
        b.value = temp;
    }

    @Override
    public void put(T t) {
        insert(t);
    }

    @Override
    public T get() {
        if (isEmpty()) {
            throw new NoSuchElementException("Priority queue is empty");
        }
        return remove(); // Remove the element with the highest priority
    }

    @Override
    public Comparator<T> getComparator() {
        return comparator;
    }

    @Override
    public Iterator<T> iterator() {
        return new Iterator<T>() {
            @Override
            public boolean hasNext() {
                return !isEmpty();
            }

            @Override
            public T next() {
                if (!hasNext()) {
                    throw new NoSuchElementException();
                }
                return get();
            }
        };
    }
}
