package factory.Sorters_and_Lists;

import sortingservice.Queue;
import sortingservice.Sorter;

import java.util.Comparator;

public class InsertionSorter<T> implements Sorter {
    @Override
    public Queue sort(Queue queue, Comparator comparator) {
        if (queue == null || comparator == null) {
            throw new IllegalArgumentException("Queue and comparator must not be null.");
        }

        if (queue.size() <= 1) {
            return queue; // Already sorted or empty
        }

        if (!(queue instanceof SingleLinkedList)) {
            throw new IllegalArgumentException("Queue must be an instance of SingleLinkedList.");
        }

        SingleLinkedList<T> singleLinkedList = (SingleLinkedList<T>) queue;
        sortSingleLinkedList(singleLinkedList, comparator);

        return singleLinkedList;
    }

    private void sortSingleLinkedList(SingleLinkedList<T> list, Comparator<T> comparator) {
        SingleLinkedList.Node<T> sortedLast = list.getHead();

        while (sortedLast.next != null) {
            SingleLinkedList.Node<T> currentNode = sortedLast.next;

            if (comparator.compare(currentNode.data, sortedLast.data) < 0) {
                sortedLast.next = currentNode.next; // Detach current node
                insertInSortedOrder(list, currentNode, comparator);
            } else {
                sortedLast = currentNode;
            }
        }
    }

    private void insertInSortedOrder(SingleLinkedList<T> list, SingleLinkedList.Node<T> nodeToInsert, Comparator<T> comparator) {
        SingleLinkedList.Node<T> insertionPoint = list.getHead();
        SingleLinkedList.Node<T> prevNode = null;

        while (insertionPoint != nodeToInsert && comparator.compare(nodeToInsert.data, insertionPoint.data) >= 0) {
            prevNode = insertionPoint;
            insertionPoint = insertionPoint.next;
        }

        if (prevNode == null) {
            nodeToInsert.next = list.getHead();
            list.setHead(nodeToInsert);
        } else {
            nodeToInsert.next = prevNode.next;
            prevNode.next = nodeToInsert;
        }
    }
}
