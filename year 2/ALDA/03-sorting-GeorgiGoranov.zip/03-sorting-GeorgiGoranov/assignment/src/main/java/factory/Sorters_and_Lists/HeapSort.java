package factory.Sorters_and_Lists;

import sortingservice.Queue;
import sortingservice.Sorter;

import java.util.Comparator;

public class HeapSort<T> implements Sorter<T> {

    @Override
    public Queue<T> sort(Queue<T> queue, Comparator<T> comparator) {
        PriorityQ<T> priorityQueue = new PriorityQ<>(comparator);

        // Populating the priority queue with elements from the queue to build the heap
        while (!queue.isEmpty()) {
            priorityQueue.insert((T) queue.get());
        }

        // Extracting the original queue with the elements now in sorted order
        while (!priorityQueue.isEmpty()) {
            queue.put(priorityQueue.remove());
        }

        return queue; // now sorted
    }
}

class TreeNode<T> {
    T value; // The value stored in the node
    TreeNode<T> left; // Reference to the left child
    TreeNode<T> right; // Reference to the right child
    TreeNode<T> parent; // Reference to the parent node

    // Constructor for creating a new tree node
    TreeNode(T value, TreeNode<T> parent) {
        this.value = value;
        this.parent = parent;
        this.left = null;
        this.right = null;
    }
}

