package factory.Sorters_and_Lists;

import sortingservice.Queue;
import sortingservice.Sorter;

import java.util.Comparator;

public class SelectionSorter<T> implements Sorter {
    @Override
    public Queue sort(Queue queue, Comparator comparator) {
        if (queue == null || comparator == null) {
            throw new IllegalArgumentException("Queue and comparator must not be null.");
        }

        if (queue.size() <= 1) {
            return queue; // Already sorted or empty
        }

        if (!(queue instanceof SingleLinkedList)) {
            throw new IllegalArgumentException("Queue must be an instance of SingleLinkedList.");
        }

        SingleLinkedList<T> singleLinkedList = (SingleLinkedList<T>) queue;
        sortSingleLinkedList(singleLinkedList, comparator);
        return singleLinkedList;
    }

    private void sortSingleLinkedList(SingleLinkedList<T> list, Comparator<T> comparator) {
        SingleLinkedList.Node<T> current = list.getHead();

        while (current != null) {
            SingleLinkedList.Node<T> minNode = findMinNodeFromCurrent(current, list, comparator);
            if (minNode != current) {
                swapNodeData(current, minNode);
            }
            current = list.getNextNode(current);
        }
    }

    private SingleLinkedList.Node<T> findMinNodeFromCurrent(SingleLinkedList.Node<T> current,
                                                            SingleLinkedList<T> list,
                                                            Comparator<T> comparator) {
        SingleLinkedList.Node<T> min = current;
        SingleLinkedList.Node<T> next = list.getNextNode(current);

        while (next != null) {
            if (comparator.compare(list.getElementAtNode(next), list.getElementAtNode(min)) < 0) {
                min = next;
            }
            next = list.getNextNode(next);
        }

        return min;
    }

    private void swapNodeData(SingleLinkedList.Node<T> node1, SingleLinkedList.Node<T> node2) {
        T temp = node1.data;
        node1.data = node2.data;
        node2.data = temp;
    }

}
