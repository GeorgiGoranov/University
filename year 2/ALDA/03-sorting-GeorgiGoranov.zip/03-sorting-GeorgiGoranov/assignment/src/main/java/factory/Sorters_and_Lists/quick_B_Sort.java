package factory.Sorters_and_Lists;

import sortingservice.Queue;
import sortingservice.Sorter;

import java.util.Comparator;

public class quick_B_Sort<T extends Comparable<T>> implements Sorter<T> {
    @Override
    public Queue<T> sort(Queue<T> queue, Comparator<T> comparator) {
        if (queue == null || queue.size() <= 1 || !(queue instanceof DoubleLinkedList<T>)) {
            return queue; // Return as-is if empty, single element, or not an instance of MyDoubleLinkedList
        }

        DoubleLinkedList<T> linkedList = (DoubleLinkedList<T>) queue;
        sort(comparator, linkedList.head, linkedList.tail);

        return linkedList;

    }
    public void sort(Comparator<T> comparator, DoubleLinkedList.Node<T> head, DoubleLinkedList.Node<T> tail) {
        if (head == tail || tail == null || head == null || head.prev == tail ) {
            return;
        }

        DoubleLinkedList.Node<T> middle = middleNode(head, tail);
        DoubleLinkedList.Node<T> pivotNode = medianOfThree(comparator, head, middle, tail);

        T v = pivotNode.data;

        DoubleLinkedList.Node<T> i = null, j = tail, p = null, q = tail;

        boolean condition = true;
        while (condition) {
            do {
                if (i == null) {
                    i = head;
                } else {
                    i = i.next;
                }
            } while (comparator.compare(i.data, v) < 0);

            boolean innerCondition = true;
            do {
                j = j.prev;
            } while ((comparator.compare(v, j.data) < 0 && j != head) && (innerCondition = true));

            if (i == j || i.prev == j) {
                condition = false;
                break;
            }
            exchange(i, j);

            if (comparator.compare(i.data, v) == 0) {
                if (p == null) {
                    p = head;
                } else {
                    p = p.next;
                }
                exchange(p, i);
            }

            if (comparator.compare(j.data, v) == 0) {
                q = q.prev;
                exchange(q, j);
            }
        }

        exchange(i, tail);
        j = i.prev;
        i = i.next;

        if (p != null) {
            for (DoubleLinkedList.Node<T> k = head; k == p || k == p.prev; k = k.next) {
                if (j != null && j.prev != null) {
                    exchange(k, j);
                    j = j.prev;
                }
            }
        }
        for (DoubleLinkedList.Node<T> k = tail.prev; k == q || k == q.next; k = k.prev) {
            exchange(k, i);
            i = i.next;
        }
        sort(comparator, head, j);
        sort(comparator, i, tail);
    }

    private void exchange(DoubleLinkedList.Node<T> i, DoubleLinkedList.Node<T> j) {
        if (i != null && j != null && i != j) {
            T temp = i.data;
            i.data = j.data;
            j.data = temp;
        }
    }

    private DoubleLinkedList.Node<T> middleNode(DoubleLinkedList.Node<T> head, DoubleLinkedList.Node<T> tail) {
        if (head == null || tail == null || head == tail) {
            return head;
        }

        DoubleLinkedList.Node<T> slow = head;
        DoubleLinkedList.Node<T> fast = head;

        while (fast != tail && fast.next != tail) {
            slow = slow.next;
            fast = fast.next.next;
        }

        return slow;
    }

    public DoubleLinkedList.Node<T> medianOfThree(Comparator<T> comparator,
                                                  DoubleLinkedList.Node<T> head,
                                                  DoubleLinkedList.Node<T> middle,
                                                  DoubleLinkedList.Node<T> tail) {
        if (head == null || middle == null || tail == null) {
            return null;
        }

        DoubleLinkedList.Node<T> median = null;

        if (comparator.compare(head.data, middle.data) > 0) {
            if (comparator.compare(middle.data, tail.data) > 0) {
                median = middle; // head > middle > tail
            } else if (comparator.compare(head.data, tail.data) > 0) {
                median = tail; // head > tail >= middle
            } else {
                median = head; // tail >= head > middle
            }
        } else {
            if (comparator.compare(head.data, tail.data) > 0) {
                median = head; // middle > head > tail
            } else if (comparator.compare(middle.data, tail.data) > 0) {
                median = tail; // middle > tail >= head
            } else {
                median = middle; // tail >= middle > head
            }
        }

        if (median != tail) {
            exchange(median, tail);
            return tail;
        } else {
            return median;
        }
    }

}
