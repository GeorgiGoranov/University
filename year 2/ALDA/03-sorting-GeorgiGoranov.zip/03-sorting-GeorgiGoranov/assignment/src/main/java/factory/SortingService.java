package factory;

import java.util.Comparator;
import java.util.function.Function;
import java.util.function.Supplier;
import java.util.stream.Stream;

import factory.Sorters_and_Lists.*;
import sortingservice.PriorityQueue;
import sortingservice.Queue;
import sortingservice.SortKind;
import sortingservice.Sorter;
import sortingservice.SorterConfiguration;
import sortingservice.SortingServiceFactory;


/**
 * Factory class to create Sorters and appropriate queues.
 *
 * @author Richard van den Ham {@code r.vandenham@fontys.nl}
 */
public class SortingService implements SortingServiceFactory {

    enum Sorters implements SorterConfiguration {
        // TODO Configure your sorters below
        // Constructor parameters: applyTeacherTests?, sortKind, queueSupplier, sorterSupplier
        SELECTION(true,
                SortKind.SELECTION,
                () -> new SingleLinkedList<>(),
                () -> new SelectionSorter()),
        INSERTION(
                true,
                SortKind.INSERTION,
                () -> new SingleLinkedList<>(),
                () -> new InsertionSorter()),

        QUICK(
                true,
                SortKind.QUICK,
                () -> new DoubleLinkedList(),
                () -> new quick_B_Sort()),

        HEAP( true,
                SortKind.HEAP,
                null,
                null){

            @Override
            public Function<Comparator, PriorityQueue> getPriorityQueueSupplier() {
                return PriorityQ::new;
            }

            @Override
            public <T> Sorter<T> getSorter() {
                return new HeapSort<>();
            }
        }
        ;



        private final boolean applyTeacherTests;
        private final SortKind sortKind;
        private final Supplier<Queue> queueSupplier;
        final Supplier<Sorter> sorterSupplier;

        private Sorters(boolean applyTeacherTests, SortKind sortKind, Supplier<Queue> queueSupplier, Supplier<Sorter> sorterSupplier) {
            this.applyTeacherTests = applyTeacherTests;
            this.sortKind = sortKind;
            this.queueSupplier = queueSupplier;
            this.sorterSupplier = sorterSupplier;
        }

        public boolean doApplyTeacherTests() {
            return applyTeacherTests;
        }

        @Override
        public String getName() {
            return this.name();
        }

        @Override
        public SortKind getSortKind() {
            return sortKind;
        }

        /**
         * By default, sorters don't have priority queue supplier.
         *
         * @return null
         */
        public Function<Comparator, PriorityQueue> getPriorityQueueSupplier() {
            return null;
        }

        @Override
        public boolean usesPriorityQueue() {
            return getPriorityQueueSupplier() != null;
        }

        @Override
        public <T> PriorityQueue<T> getPriorityQueue(Comparator<T> comparator) {
            return getPriorityQueueSupplier().apply(comparator);
        }

        @Override
        public <T> Queue<T> getQueue() {
            return queueSupplier.get();
        }

        @Override
        public <T> Sorter<T> getSorter() {
            return sorterSupplier.get();
        }
    }

    @Override
    public Stream<SorterConfiguration> streamSorterConfigurations() {
        return Stream.of(Sorters.values())
                .filter(Sorters::doApplyTeacherTests)
                .map( sorter -> (SorterConfiguration)sorter);
    }

}
