package factory;

import factory.Sorters_and_Lists.PriorityQ;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import sortingservice.SortKind;

import java.util.Comparator;
import java.util.PriorityQueue;
import java.util.function.Function;

import static org.junit.jupiter.api.Assertions.*;

class SortingServiceTest {
    private Comparator<Integer> comparator;

    @BeforeEach
    void setUp() {
        comparator = Integer::compare;
    }

    @Test
    void testGetPriorityQueueSupplier() {
        for (SortingService.Sorters sorter : SortingService.Sorters.values()) {
            if (sorter.getSortKind() != SortKind.HEAP) {
                assertNull(sorter.getPriorityQueueSupplier(),
                        "getPriorityQueueSupplier should return null for non-HeapSort configurations.");
            }
        }
    }

    @Test
    void testUsesPriorityQueue() {
        for (SortingService.Sorters sorter : SortingService.Sorters.values()) {
            if (sorter.getSortKind() != SortKind.HEAP) {
                assertFalse(sorter.usesPriorityQueue(),
                        "usesPriorityQueue should return false for non-HeapSort configurations.");

            }
        }
    }

    @Test
    void testGetPriorityQueue() {
        for (SortingService.Sorters sorter : SortingService.Sorters.values()) {
            if (sorter.getSortKind() != SortKind.HEAP) {
                assertThrows(NullPointerException.class,
                        () -> sorter.getPriorityQueue(comparator),
                        "getPriorityQueue should throw NullPointerException for non-HeapSort configurations.");

            }
        }
    }

}