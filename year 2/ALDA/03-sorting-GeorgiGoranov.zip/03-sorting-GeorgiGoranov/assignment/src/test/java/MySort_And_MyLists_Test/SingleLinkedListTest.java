package MySort_And_MyLists_Test;

import factory.Sorters_and_Lists.DoubleLinkedList;
import factory.Sorters_and_Lists.SingleLinkedList;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Spliterator;

import static org.junit.jupiter.api.Assertions.*;

class SingleLinkedListTest {

    private SingleLinkedList<Integer> list;

    @BeforeEach
    void setUp() {
        list = new SingleLinkedList<>();
    }

    @Test
    void testIsEmptyOnNewList() {
        assertTrue(list.isEmpty());
    }

    @Test
    void testSizeOnNewList() {
        assertEquals(0, list.size());
    }

    @Test
    void testPutAndSize() {
        list.put(1);
        assertFalse(list.isEmpty());
        assertEquals(1, list.size());
    }

    @Test
    void testGetOnEmptyList() {
        assertThrows(IllegalStateException.class, () -> list.get());
    }

    @Test
    void testPutAndGet() {
        list.put(1);
        list.put(2);
        assertEquals(1, list.get());
        assertEquals(2, list.get());
    }

    @Test
    void testSizeAfterGet() {
        list.put(1);
        list.put(2);
        list.get();
        assertEquals(1, list.size());
    }

    @Test
    void testIterator() {
        list.put(1);
        list.put(2);
        Iterator<Integer> iterator = list.iterator();
        assertTrue(iterator.hasNext());
        assertEquals(1, iterator.next());
        assertTrue(iterator.hasNext());
        assertEquals(2, iterator.next());
        assertFalse(iterator.hasNext());
    }

    @Test
    void testIteratorOnEmptyList() {
        Iterator<Integer> iterator = list.iterator();
        assertFalse(iterator.hasNext());
        assertThrows(IllegalStateException.class, iterator::next);
    }

    @Test
    void testForEach() {
        list.put(1);
        list.put(2);
        int[] sum = {0};
        list.forEach(n -> sum[0] += n);
        assertEquals(3, sum[0]);
    }
    @Test
    public void testGetSizeAfterGet() {

        list.put(10);
        list.put(20);

        assertEquals(2, list.size());
        list.get();
        assertEquals(1, list.size());
        list.get();
        assertEquals(0, list.size());
    }

    @Test
    void testSpliteratorForEachRemaining() {
        list.put(1);
        list.put(2);
        list.put(3);

        Spliterator<Integer> spliterator = list.spliterator();
        List<Integer> elements = new ArrayList<>();
        spliterator.forEachRemaining(elements::add);

        assertEquals(3, elements.size());
        assertArrayEquals(new Integer[]{1, 2, 3}, elements.toArray(new Integer[0]));
    }

    //additional tests for double linked list

    @Test
    public void testGetFromEmptyList() {
        DoubleLinkedList<Integer> list = new DoubleLinkedList<>();
        assertThrows(IllegalStateException.class, list::get,
                "Calling get on an empty list should throw an IllegalStateException.");
    }

    @Test
    public void testIteratorNextOnEmptyList() {
        DoubleLinkedList<Integer> list = new DoubleLinkedList<>();
        Iterator<Integer> iterator = list.iterator();
        assertFalse(iterator.hasNext(), "Iterator should not have next on an empty list.");
        assertThrows(IllegalStateException.class, iterator::next,
                "Calling next on an iterator of an empty list should throw an IllegalStateException.");
    }


}