package MySort_And_MyLists_Test;

import factory.ServiceFinder;
import factory.Sorters_and_Lists.*;
import factory.SortingService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.MethodSource;
import sortingservice.Queue;
import sortingservice.SortKind;
import sortingservice.Sorter;
import sortingservice.SorterConfiguration;

import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;


import static org.assertj.core.api.AssertionsForClassTypes.assertThat;
import static org.junit.jupiter.api.Assertions.*;

class SortersTest {

    private PriorityQ<Integer> priorityQueue;
    private Comparator<Integer> comparator;
    private final SortingService sortingService = new SortingService();

    @BeforeEach
    void setUp() {
        comparator = Integer::compare;
        priorityQueue = new PriorityQ<>(comparator);
    }

    public static Stream<SorterConfiguration> getSortersToTest() {
        return ServiceFinder.getFactory().streamSorterConfigurations();
    }

    private Queue<Integer> fillRandom(Queue<Integer> queue, int size) {
        Random random = new Random();
        for (int i = 0; i < size; i++) {
            queue.put(random.nextInt(20));
        }
        return queue;
    }

    public boolean isSorted(Queue<Integer> queue, Comparator<Integer> comparator) {
        if(queue.isEmpty() || queue.size() == 1){
            return true;
        }
        Iterator<Integer> iterator = queue.iterator();
        Integer current, previous = iterator.next();

        while (iterator.hasNext()) {
            current = iterator.next();
            if (comparator.compare(previous, current) > 0) {
                return false;
            }
            previous = current;
        }

        return true;
    }

    @Test
    void testSortOnEmptyLinkedList() {
        Sorter<Integer> sorter = new InsertionSorter<>();
        SingleLinkedList<Integer> emptyList = new SingleLinkedList<>();
        Comparator<Integer> comparator = Comparator.naturalOrder();

        Queue<Integer> result = sorter.sort(emptyList, comparator);

        assertTrue(result.isEmpty(), "Sorted linked list should be empty.");
        assertSame(emptyList, result, "Returned linked list should be the same as the input for an empty list.");
    }

    @ParameterizedTest
    @MethodSource("MySort_And_MyLists_Test.SortersTest#getSortersToTest")
    void sort(SorterConfiguration sorterConfig) {

        Queue<Integer> queue;
        Sorter<Integer> sorter;

        if (sorterConfig.getSortKind() == SortKind.HEAP) {
            queue = new PriorityQ<>(comparator);
            sorter = new HeapSort<>();
        } else {
            queue = sorterConfig.getQueue();
            sorter = sorterConfig.getSorter();
        }

        // Fill the queue with random data
        queue = fillRandom(queue, 5);

        // Perform the sorting
        Queue<Integer> sortedQueue = sorter.sort(queue, comparator);

        // Assertions
        assertThat(sortedQueue).isSameAs(queue);
        queue.forEach(System.out::println);
        assertThat(isSorted(sortedQueue, comparator)).isTrue();

    }


    @ParameterizedTest
    @MethodSource("MySort_And_MyLists_Test.SortersTest#getSortersToTest")
    void testSortWithSingleElementQueue(SorterConfiguration sorterConfig) {
        Queue<Integer> singleElementQueue;
        Sorter<Integer> sorter;

        if (sorterConfig.getSortKind() == SortKind.HEAP) {
            // Create a PriorityQ for HeapSort and use it as the singleElementQueue
            singleElementQueue = new PriorityQ<>(comparator);
            sorter = new HeapSort<>();
        } else {
            // Use the queue and sorter provided by the configuration
            singleElementQueue = sorterConfig.getQueue();
            sorter = sorterConfig.getSorter();
        }

        // Add a single element
        singleElementQueue.put(1);

        // Perform the sorting
        Queue<Integer> sortedQueue = sorter.sort(singleElementQueue, comparator);

        // Assertions
        assertEquals(1, sortedQueue.size(), "Sorted queue should have one element for a single-element input queue.");
        assertSame(singleElementQueue, sortedQueue, "Returned queue should be the same as the input for a single-element queue.");
        assertEquals(1, sortedQueue.get(), "The element in the queue should be unchanged.");
    }



    @Test
    void testSorterConfigurationNames() {
        SortingService sortingService = new SortingService();
        List<SorterConfiguration> configurations = sortingService.streamSorterConfigurations()
                .collect(Collectors.toList());

        assertFalse(configurations.isEmpty(), "No sorter configurations found.");

        for (SorterConfiguration config : configurations) {
            String expectedName = config.getName(); // Assuming the name is the simple class name
            String actualName = config.getName();

            assertNotNull(actualName, "Sorter configuration name should not be null.");
            assertEquals(expectedName, actualName, "Sorter configuration name should match the expected name.");
        }
    }




    @Test
    void testStreamSorterConfigurations() {
        List<SorterConfiguration> configurations = sortingService.streamSorterConfigurations()
                .collect(Collectors.toList());

        assertFalse(configurations.isEmpty(), "No sorter configurations found.");

    }

    @Test
    void testSorterCreation() {
        sortingService.streamSorterConfigurations().forEach(config -> {
            assertNotNull(config.getSorter(), "Sorter should not be null.");
            assertTrue(config.getSorter() instanceof sortingservice.Sorter,
                    "Sorter should be an instance of Sorter.");
        });
    }

    @Test
    void testQueueCreation() {
        sortingService.streamSorterConfigurations().forEach(config -> {
            if (config.getSortKind() != SortKind.HEAP) { // Skip for HeapSort or other specific sorters
                assertNotNull(config.getQueue(), "Queue should not be null for non-HeapSort configurations.");
                assertTrue(config.getQueue() instanceof sortingservice.Queue,
                        "Queue should be an instance of Queue for non-HeapSort configurations.");
            }
        });
    }




    @Test
    void testSortKind() {
        sortingService.streamSorterConfigurations().forEach(config -> {
            assertNotNull(config.getSortKind(), "SortKind should not be null.");
            assertTrue(config.getSortKind() instanceof sortingservice.SortKind,
                    "SortKind should be an instance of SortKind.");
        });
    }

    //quick sort

    @Test
    void testSortWithDuplicateElements() {
        quick_B_Sort<Integer> sorter = new quick_B_Sort<>();

        Comparator<Integer> comparator = Integer::compare;

        // Creating nodes with duplicate values
        DoubleLinkedList.Node<Integer> head = new DoubleLinkedList.Node<>(2);
        DoubleLinkedList.Node<Integer> node2 = new DoubleLinkedList.Node<>(1);
        DoubleLinkedList.Node<Integer> node3 = new DoubleLinkedList.Node<>(2); // Duplicate of head
        DoubleLinkedList.Node<Integer> tail = new DoubleLinkedList.Node<>(3);

        // Linking nodes
        head.next = node2; node2.prev = head;
        node2.next = node3; node3.prev = node2;
        node3.next = tail; tail.prev = node3;

        // Applying sort
        sorter.sort(comparator, head, tail);

        // Verifying the list is sorted and duplicates are handled correctly
        boolean isSortedCorrectly = head.data <= node2.data && node2.data <= node3.data && node3.data <= tail.data;
        assertTrue(isSortedCorrectly, "List should be sorted correctly, even with duplicates.");
    }

    @Test
    void testSortSpecificLoop() {
        quick_B_Sort<Integer> sorter = new quick_B_Sort<>();
        Comparator<Integer> comparator = Integer::compare;

        // Creating and linking nodes in a specific order
        DoubleLinkedList.Node<Integer> head = new DoubleLinkedList.Node<>(3);
        DoubleLinkedList.Node<Integer> node2 = new DoubleLinkedList.Node<>(4); // This will be 'i' after some swaps
        DoubleLinkedList.Node<Integer> node3 = new DoubleLinkedList.Node<>(1); // This will be 'q' after some swaps
        DoubleLinkedList.Node<Integer> tail = new DoubleLinkedList.Node<>(2);

        head.next = node2; node2.prev = head; node2.next = node3; node3.prev = node2; node3.next = tail; tail.prev = node3;

        // Applying sort - this should trigger the specific loop
        sorter.sort(comparator, head, tail);

        // Validate if the list is sorted correctly
        boolean isSorted = head.data <= node2.data && node2.data <= node3.data && node3.data <= tail.data;
        assertTrue(isSorted, "The list should be sorted after sort operation.");
    }

    //heap sort

    @Test
    public void testSortWithIntegers() {
        HeapSort<Integer> heapSort = new HeapSort<>();
        Queue<Integer> queue = new DoubleLinkedList<>();

        // Populate the queue
        queue.put(4);
        queue.put(1);
        queue.put(3);
        queue.put(2);

        // Apply sorting
        queue = heapSort.sort(queue, comparator);

        // Check if the queue is sorted
        assertTrue(isSortedHeap(queue, comparator), "Queue should be sorted.");
    }

    private <T> boolean isSortedHeap(Queue<T> queue, Comparator<T> comparator) {
        if(queue.isEmpty() || queue.size() == 1){
            return true;
        }

        T previous = queue.get();
        while (!queue.isEmpty()) {
            T current = queue.get();
            if (comparator.compare(previous, current) > 0) {
                return false;
            }
            previous = current;
        }

        return true;
    }

    //priority q tests
    @Test
    public void testIsEmptyOnNewQueue() {
        PriorityQ<Integer> priorityQueue = new PriorityQ<>(comparator);
        assertTrue(priorityQueue.isEmpty(), "Newly created queue should be empty.");
    }

    @Test
    public void testInsertAndRemove() {
        PriorityQ<Integer> priorityQueue = new PriorityQ<>(comparator);;
        priorityQueue.insert(3);
        priorityQueue.insert(1);
        priorityQueue.insert(2);

        assertFalse(priorityQueue.isEmpty(), "Queue should not be empty after inserts.");
        assertEquals(1, priorityQueue.remove(), "Remove should return the smallest element (1).");
        assertEquals(2, priorityQueue.remove(), "Remove should return the next smallest element (2).");
        assertEquals(3, priorityQueue.remove(), "Remove should return the next smallest element (3).");
        assertTrue(priorityQueue.isEmpty(), "Queue should be empty after all elements are removed.");
    }

    @Test
    public void testSize() {
        PriorityQ<Integer> priorityQueue = new PriorityQ<>(comparator);
        assertEquals(0, priorityQueue.size(), "Newly created queue should have size 0.");

        priorityQueue.insert(3);
        priorityQueue.insert(1);
        assertEquals(2, priorityQueue.size(), "Queue should have size 2 after two inserts.");
    }

    @Test
    public void testRemoveFromEmptyQueue() {
        PriorityQ<Integer> priorityQueue = new PriorityQ<>(comparator);
        assertThrows(NoSuchElementException.class, priorityQueue::remove,
                "Removing from an empty queue should throw NoSuchElementException.");
    }

    @Test
    public void testIterator() {
        PriorityQ<Integer> priorityQueue = new PriorityQ<>(comparator);
        priorityQueue.insert(3);
        priorityQueue.insert(1);
        priorityQueue.insert(2);

        int[] expectedOrder = {1, 2, 3};
        int index = 0;
        for (int value : priorityQueue) {
            assertEquals(expectedOrder[index++], value, "Iterator should iterate in sorted order.");
        }
    }

    //tests for not covered methods

    @Test
    public void testPut() {
        PriorityQ<Integer> priorityQueue = new PriorityQ<>(comparator);
        priorityQueue.put(3);
        priorityQueue.put(1);
        priorityQueue.put(2);

        assertEquals(3, priorityQueue.size(), "Queue should have 3 items after 3 puts.");
    }

    @Test
    public void testGet() {
        PriorityQ<Integer> priorityQueue = new PriorityQ<>(comparator);
        priorityQueue.put(3);
        priorityQueue.put(1);
        priorityQueue.put(2);

        assertEquals(1, priorityQueue.get(), "Get should return the smallest element (1).");
        assertEquals(2, priorityQueue.get(), "Get should return the next smallest element (2).");
        assertEquals(3, priorityQueue.get(), "Get should return the next smallest element (3).");
    }

    @Test
    public void testGetFromEmptyQueue() {
        PriorityQ<Integer> priorityQueue = new PriorityQ<>(comparator);
        assertThrows(NoSuchElementException.class, priorityQueue::get,
                "Getting from an empty queue should throw NoSuchElementException.");
    }

    @Test
    public void testGetComparator() {

        PriorityQ<Integer> priorityQueue = new PriorityQ<>(comparator);

        assertSame(comparator, priorityQueue.getComparator(),
                "getComparator should return the comparator used to create the queue.");
    }

    //additional tests for qicksort

    @Test
    public void testMedianOfThreeWithNullNodes() {
        quick_B_Sort<Integer> sorter = new quick_B_Sort<>();
        Comparator<Integer> comparator = Integer::compare;

        assertNull(sorter.medianOfThree(comparator, null, null, null),
                "Median of three null nodes should be null.");
    }

    @Test
    public void testMedianOfThreeVariousScenarios() {
        quick_B_Sort<Integer> sorter = new quick_B_Sort<>();


        DoubleLinkedList.Node<Integer> head, middle, tail;

        // Scenario: head > middle > tail
        head = new DoubleLinkedList.Node<>(3);
        middle = new DoubleLinkedList.Node<>(2);
        tail = new DoubleLinkedList.Node<>(1);
        assertEquals(middle.data, sorter.medianOfThree(comparator, head, middle, tail).data,
                "Median should have the same data as the middle node.");

        // Scenario: head > tail >= middle
        head = new DoubleLinkedList.Node<>(3);
        middle = new DoubleLinkedList.Node<>(1);
        tail = new DoubleLinkedList.Node<>(2);
        assertEquals(tail.data, sorter.medianOfThree(comparator, head, middle, tail).data,
                "Median should have the same data as the tail node.");

        // Scenario: middle > head > tail
        head = new DoubleLinkedList.Node<>(2);
        middle = new DoubleLinkedList.Node<>(3);
        tail = new DoubleLinkedList.Node<>(1);
        assertEquals(head.data, sorter.medianOfThree(comparator, head, middle, tail).data,
                "Median should have the same data as the head node.");

        // Scenario: middle > tail >= head
        head = new DoubleLinkedList.Node<>(1);
        middle = new DoubleLinkedList.Node<>(3);
        tail = new DoubleLinkedList.Node<>(2);
        assertEquals(tail.data, sorter.medianOfThree(comparator, head, middle, tail).data,
                "Median should have the same data as the tail node.");

    }



    @Test
    void testSortWithNullQueue() {
        InsertionSorter<Integer> sorter = new InsertionSorter<>();
        Comparator<Integer> comparator = Integer::compare;

        assertThrows(IllegalArgumentException.class,
                () -> sorter.sort(null, comparator),
                "Should throw IllegalArgumentException when queue is null");
    }

    @Test
    void testSortWithNullComparator() {
        InsertionSorter<Integer> sorter = new InsertionSorter<>();
        SingleLinkedList<Integer> queue = new SingleLinkedList<>();

        assertThrows(IllegalArgumentException.class,
                () -> sorter.sort(queue, null),
                "Should throw IllegalArgumentException when comparator is null");
    }




}