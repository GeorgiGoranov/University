## Design artefacts

- [Use case diagram](/design/usecasediagramContainer.svg)
- [Domain model](/design/domain-model.svg)
