import { useState } from "react"

const CreateNewUser = () => {

    const [id, setID] = useState('')
    const [username, setUsername] = useState('')
    const [email, setEmail] = useState('')
    const [password, setPassword] = useState('')
    const [role, setRole] = useState('')
    const [error, setError] = useState(null)


// e - > event object 
    const handleSubmit = async (e) =>{
        e.preventDefault()

        const user = {id,username, email, password, role}

        const response = await fetch('/api/users',{
            method: 'POST',
            body: JSON.stringify(user),
            headers: {
                'Content-Type': 'application/json'
            }
        })
        const json = await response.json()

        if(!response.ok){
            setError(json.error)
        }
        if(response.ok){
            setUsername('')
            setEmail('')
            setPassword('')
            setRole('')

            setError(null)
            console.log('new user added', json)
        }
    }

    return(
        <form className="create" onSubmit={handleSubmit}>
            <h3>Add a New User</h3>

            <label>ID</label>
            <input type="text" 
            onChange={(e) => setID(e.target.value)}
            value={id}
            ></input>

            <label>Username</label>
            <input type="text" 
            onChange={(e) => setUsername(e.target.value)}
            value={username}
            ></input>

            <label>Email</label>
            <input type="text" 
            onChange={(e) => setEmail(e.target.value)}
            value={email}
            ></input>

            <label>Password</label>
            <input type="text" 
            onChange={(e) => setPassword(e.target.value)}
            value={password}
            ></input>

            <label>Role</label>
            <input type="text" 
            onChange={(e) => setRole(e.target.value)}
            value={role}
            ></input>

            <button type="submit">Add new User</button>
            {error && <div className="error">{error}</div>}
        </form>
    )
}

export default CreateNewUser