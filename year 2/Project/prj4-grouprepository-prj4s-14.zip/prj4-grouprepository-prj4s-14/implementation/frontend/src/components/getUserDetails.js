const userDetails = ({users}) => {
    return (
        <div className="user-details">
            <h4>
                {users.username}
            </h4>
            <p><strong>Email: </strong>{users.email}</p>
            <p><strong>Password: </strong>{users.password}</p>
            <p>{users.createdAt}</p>
        </div>
    )
}

export default userDetails