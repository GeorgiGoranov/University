import { Link } from 'react-router-dom'

const Navbar = () => {
  return (
    <header>
      <div className="container">
        <h1>CPL International - Container Tracking</h1>
        <Link to="/">
        </Link>
      </div>
    </header>
  )
}

export default Navbar
