
import { useEffect, useState } from 'react'

//components 
import UserDetails from '../components/getUserDetails'//In React, component names must start with an uppercase letter.
import CreateNewUser from '../components/createNewUser'

const Home = () => {

  const [users, setUsers] = useState(null)

  useEffect(() => {
    const fetchUsers = async () => {
      const response = await fetch('/api/users')
      const json = await response.json()

      if (response.ok) {
        setUsers(json)
      }
    }

    fetchUsers()

  }, [])//[] fire only once 

  return (
    <div className="home">
      <div className='users'>
        {users && users.map((users) => (
          <UserDetails key={users._id} users={users} />
        ))}
      </div>
      <CreateNewUser/>
    </div>
  )
}

export default Home;
