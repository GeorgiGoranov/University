const express = require('express')

const {createUser, getAllUsers, getSingleUser} = require('../controllers/userController')


const router = express.Router()

//get all users
router.get('/', getAllUsers)

//get one user
router.get('/:id', getSingleUser)

//post new user
router.post('/', createUser)

//delete user
router.delete('/:id', (req, res) => {
    res.json({mssg: 'DELETE user'})
})

//update user
router.patch('/:id', (req, res) => {
    res.json({mssg: 'UPDATE user'})
})

module.exports = router