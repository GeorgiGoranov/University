## PRJ4 Container tracking website

This project is a MERN stack project, which means it involves MongoDB, Express js, React and Node.js.
Here we provide the different artefacts developed during the starting phase of the projet.

- [Analysis](/analysis) - Analysis artefacts
- [Design](/design) - Design artefacts

## Team Roles
- **Scrum Master:** Aleix Bossa
- **Product Owner:** Moritz Muescher

## Process
- Sprint start and end on Monday. On each Monday we will start with the Sprint Review, followed by a brief Retrospective, and then we start the new Sprint.
- In the Sprint Review we briefly talk about what we did the past week and what problems we encountered.
- In the Sprint meeting we talk about and document what our overall goals for the sprint are, which user stories we are going to work on, and finally we make sure everyone assigns themselves to a task to start working on.
- When someone's task is finished they will assign themselves to a new task.
- If necessary, on a flexible basis we make time to explain each other things we have done and to brainstorm on more difficult problems a group member might encounter.

### Definition of Done
A task is deemed complete when:
- All features have achieved production quality.
- The work has undergone team review.
- The product owner has given acceptance.

### Sprint Goals
- Achieve the definition of done.
- Satisfy stakeholders, which includes the team members.

## Team Expectations
For a successful communication in the team and with other stakeholders we
agree on: 
- be on time and active participation in the scrum meetings
- talking about our problems within the project
- be kind to one another and respecting our individual values

For assurance of reliability of every team member we agree on:
- mindful use of the scrum board, e.g. don’t move something into done that has not
been reviewed
- always review before moving a specific element to the next phase of development
- holding each other accountable, meaning making sure everyone is on pace and
knows what to work on

To insure a respectful interaction we agree on:
- respectful communication with each other
- no foul language
- keeping in consideration each of our respective values
- Constructive feedback only

Other agreements / expectations:
- communicate to the other group members if you are running late, if late less than 30
minutes we start working, but delay the full scrum meeting until they are present
- In case a member is late or missing, the group will briefly explain what they did on
that working session.


