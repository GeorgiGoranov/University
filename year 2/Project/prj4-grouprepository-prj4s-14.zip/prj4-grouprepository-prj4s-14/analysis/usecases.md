# Use cases

## Table of contents
- [Login](#login)
- [Search container](#search_container)
- [Set favourite containers](#set_favorite_container)
- [Create a new user](#create_a_new_user)
- [Edit user](#edit_user)
- [Delete user](#delete_user)
- [Access Management Dashboard](#access_management_dashboard)


<a name="login"></a>
| Name:          | Login                                                                                                                                                                      |
|----------------|--------------------------------|
| Description:   | Customer logs into the website with the provided account details.                                                                                      |
| Pre-Condition: | link to providing user details                                                                                                                                                                                         |
| Scenario:      | 1. Customer input the user details.<br> 2. Click the login button.|
| Result:        | Customer is logged in  |

<a name="search_container"></a>
| Name:          | Search container    |
|----------------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Description:   | Customer is able to seaarch for the desired container with the container information.                                                                                     |
| Pre-Condition: | Customer must be logged in.                          |
| Scenario:      | 1. Customer input the user details.<br> 2. Click the login button.<br> 3. System displays main screen. <br> 4. Customer inputs the container information. <br> 5. System displays container status. |
| Result:        | Customer has found its container.  |

<a name="set_favorite_container"></a>
| Name:          | Set favourite containers                    |
|----------------|--------------------------------|
| Description:   | Customer sets the container to favourites so that he can accessi it faster later on.                                                                                      |
| Pre-Condition: | Customer has to have searched for a container.  |
| Scenario:      | 1. System displays information about the container. <br> 2. Customer clicks the favourite button. <br> 3. System saves the container as favourite.|
| Result:        | Customer has saved a container as favourite.  |

<a name="create_a_new_user"></a>
| Name: | Create user account |
| --- | --- |
| Actor: | Admin |
| Description: | Admin wants to create a user account |
| Pre-condition: | Admin is logged in as admin|
| Scenario: | 1. Actor indicates that he wants to create a user account<br />2. System asks for user account information<br />3. Actor gives user account information<br /> 4. Actor confirms user account creation <br> 5. System creates user account |
| Result: | User account was created<br />
| Exception: | 4. System informs that user account information is already used<br />&emsp;4.1 Use Case ends here<br />4. System informs that passwords doesn't match<br />&emsp;4.1 Use Case ends here |
| Extension: | / |

<a name="edit_user"></a>
| Name: | Edit user account |
| --- | --- |
| Actor: | Admin |
| Description: | Admin wants to edit a user account |
| Pre-condition: | Admin is logged in as admin|
| Scenario: | 1. Actor indicates that he wants to edit a user account<br />2. System displays user account information and option to edit it<br />3. Actor makes changes to user account information<br /> 4. Actor confirms changes of user account <br> 5. System overrides user account information|
| Result: | User account information was edited<br />
| Exception: | 4. System informs that user account information is already used<br />&emsp;4.1 Use Case ends here<br />4. System informs that passwords doesn't match<br />&emsp;4.1 Use Case ends here |
| Extension: | / |

<a name="delete_user"></a>
| Name: | Delete user account |
| --- | --- |
| Actor: | Admin |
| Description: | Admin wants to delete a user account |
| Pre-condition: | Admin is logged in as admin|
| Scenario: | 1. Actor indicates that he wants to delete a user account<br />2. System asks for confirmation<br />3. Actor confirms deletion of user account<br /> 4. System deletes user account |
| Result: | User account was deleted<br />
| Exception: | / |
| Extension: | / |

<a name="access_management_dashboard"></a>
| Name:          | Access Management Dashboard                                                                                                                                                                       |
|----------------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Actor: | Admin |
| Description:   | An Admin [logs in](#login) and sees the management dashboard                                                                                   |
| Pre-Condition: | The Actor must be an Admin                                                                                                                                                                                       |
| Scenario:      | 1. Inputs login information. <br> 2. Goes in the main menu and sees the management dashboard<br>|
| Result:        | The Actor sees the management dashboard |
|Exeptions: | 1a. Input is incorrect <br> 1.1. The user corrects the login mistke <br> 1.2 Goes back to step 1|