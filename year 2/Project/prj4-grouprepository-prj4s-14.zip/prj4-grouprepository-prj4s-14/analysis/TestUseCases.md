# Test Scenarios

## Table of contents
- [Login](#login)
- [Search container](#search_container)
- [Set favourite containers](#set_favorite_container)
- [Create a new user](#create_a_new_user)
- [Edit user](#edit_user)
- [Delete user](#delete_user)
- [Access Management Dashboard](#access_management_dashboard)

<a name="login"></a>
| Name:          | Login                                                                                                                                                                      |
|----------------|--------------------------------|
| Description:   | Customer logs into the website with the provided account details: Username: Aleix Password: tooGood                                                             |
| Pre-Condition: | Customer must have the provided login details.                          |
| Scenario:      | Customer inputs the username Aleix and the pasword tooGood and he clicks on the login button.|
| Expected result:        | Customer is succsefully logged in with Username: Aleix and Password: tooGood. |

<a name="search_container"></a>
| Name:          | Search container    |
|----------------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Description:   | Customer is able to seaarch for the container with id 123456789 and carrier code NPO.                                                                                     |
| Pre-Condition: | Customer must be logged in.                          |
| Scenario:      | Customer inputs the container id 123456789 ane carrier code NPO on the search box.|
| Expected result: | Customer has found the correct container information. |

<a name="set_favorite_container"></a>
| Name:          | Set favourite containers                    |
|----------------|--------------------------------|
| Description:   | Customer sets the container to favourites so that he can accessi it faster later on.                                                                                      |
| Pre-Condition: | Customer has to have searched for a container with id 123456789 and carrier code NPO.  |
| Scenario:      | Customer clicks the add to favourite button|
| Result:        | System has saved a container as favourite.  |

<a name="create_a_new_user"></a>
| Name: | Create user account |
| --- | --- |
| Actor: | Admin |
| Description: | Admin wants to create a user account |
| Pre-condition: | Admin is logged in as admin|
| Scenario: | 1. Actor clicks button "create user account"<br />2. System asks for username or email and password and (optional) organization<br />3. Actor inputs username "MaxMustermann", email "max@mustermann.com" and password "Password1234""<br /> 4. Actor clicks "confirm" button <br> 5. The system shows with the final look of the created user with a popup and waits for confirmation once more. <br> 6. Clicks on the register button to finalize the registration. <br> 7. System creates user account |
| Result: | User account was created and email with login credentials is sent<br />
| Exception: | 4. System informs that user account with username "MaxMustermann" is already used<br />&emsp;4.1 Use Case ends here<br />4. System informs that password "Password1234" and "Password123" don't match<br />&emsp;4.1 Use Case ends here <br> 4. Actor leaves email input field empty <br>&emsp;4.1 Use Case ends here|
| Extension: | / |

<a name="edit_user"></a>
| Name: | Edit user account |
| --- | --- |
| Actor: | Admin |
| Description: | Admin wants to edit a user account |
| Pre-condition: | Admin is logged in as admin|
| Scenario: | 1. Actor clicks "edit user account" button<br />2. System displays user account information and option to edit it<br />3. Actor changes username form "MaxMustermann" to "MaxMustermann2"<br /> 4. Actor clicks "confirm" button <br> 5. System overrides user account information|
| Result: | User account information was edited<br />
| Exception: | 4. System informs that username "MaxMustermann2" is already used<br />&emsp;4.1 Use Case ends here|
| Extension: | / |

<a name="delete_user"></a>
| Name: | Delete user account |
| --- | --- |
| Actor: | Admin |
| Description: | Admin wants to delete a user account |
| Pre-condition: | Admin is logged in as admin|
| Scenario: | 1. Actor clicks "delete user account" button<br />2. System displays "confirm" button<br />3. Actor presses "confirm" button<br /> 4. System deletes user account |
| Result: | User account was deleted<br />
| Exception: | / |
| Extension: | / |


<a name="access_management_dashboard"></a>
| Name:          | Access Management Dashboard                                                                                                                                                                       |
|----------------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Actor: | Admin |
| Description:   | An Admin logs in and sees the management dashboard                                                                                   |
| Pre-Condition: | The Actor must be an admin                                                                                                                                                                                       |
| Scenario:      | 1. Inputs login information - max@mustermann.com and Password1234. <br> 2. Actor enters the main menu and sees the management dashboard<br>|
| Result:        | The Actor sees the management dashboard |
|Exeptions: | 1a. Input is incorrect <br> 1.1. The user corrects the login mistke <br> 1.2 Goes back to step 1|