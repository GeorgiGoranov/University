## Domain model

<img src="domain-model.svg" alt="domain">
