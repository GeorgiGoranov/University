# User Stories

## Customer
- As a customer, I want to log in, to get access to the website.
- As a customer, I want to input a container ID and a carrier code to see status information about my containeer.
- As a customer, I want to be able to see my tracked containers on a map.
- As a customer, I want to be able to favourite containers to quickly see the status information at any time.

## Admin
- As an admin, I want to log in, to get access to the website.
- As an admin, I want to be able to create user accounts.
- As an admin, I want to be able to delete user accounts.
- As an admin, I want to be able to edit user account information.

