# Project Charter - GROUP 14


## Chapter 2: Business Case

CPL International is a shipping agency from Germany that ships containers for their customers all over the world. We got in contact with them for this project, because they need their own container tracking website. Currently, if their customers request status information about the containers they shipped, they exchange information via email. This is not really efficient and costs them a lot of time. 
There are already container tracking websites that are free to use, but CPL International wants to have their own, branded, container tracking website to provide a more professional experience towards their customers.

The container tracking website should look like it’s part of CPL International’s company and should give their customers the ability to track their containers and receive status information about them without needing to get in contact with an employee of CPL International directly.


This container tracking website will be very beneficial for CPL International. 
As mentioned, it will make the company look better and more professional towards their customers, if they have their own tracking website with their corporate design. Most likely it will also be beneficial for their customers and will boost the customer experience, because they can immediately find out where their cargo is without having to communicate with an employee. The same applies to CPL International, because they don’t need to deal with that many calls and emails asking where containers are anymore. Instead they can spend their time working on other, more important things and will be more productive.

There is also a risk for CPL International to run a container tracking website. If there are too many users using that website, the api calls will cost them a lot of money. To prevent possible unauthorized use of this website, CPL International wants us to implement a secure login authorization for the website, so that only authorized clients can use the website.


The development of this container tracking website is not only a response to the business needs of CPL International. This website will be a big step for the digital future of the company and will improve their digital presence a lot. Also it will save both the company, as well as their customers a lot of time. In general CPL International thinks that the benefits of their own container tracking website outweigh the risk that it has.


## Chapter 3: Approach

In this project we decided to use scrum since we feel like it will be the best option for us. We will be using Github’s taskboard to keep track of the progress. For the moment we set the sprint length as one week. We decided this methodology because it is the one we have more experience with, in general, and it is also the one that suits us better for this project. Since the timeline that we have is divided in weeks and that our project is highly dynamic.

Regarding the planning, we are going to be establishing the product backlog and the sprint backlog. Firstly we will use the requirements that we received from the stakeholders to create our user stories. Then we will add them to our product backlog and we will tag those user stories with a priority. Additionally, we will link those to specific tasks that need to be completed in order to complete the user story. In each sprint planning meeting, we will be discussing the progress and having a look at the product backlog to see which user stories should be moved to the sprint backlog which has the user stories and tasks that are going to be worked on during that iteration.

As said, the sprints are going to be weekly, so we will have a sprint planning at the start of the week and a sprint review and retrospective at the end of the week. We will also be doing daily stand-up meetings so that we track the progress in a better way.

This approach is very suitable with our stakeholders since we are able to contact them at every iteration of the scrum process.

## Chapter 4

In scope 
We're making a web app that tracks cargo ships in real-time. This app will show important info about what each ship is carrying and its current status. We're using a map to show where each ship is (possibility of 3D Map). Only customers who have received a special login given from us can go on the web app and use it. To make our web app work, we're going to use an API that helps us track the ships. We're going to build our app using React for the parts that people see and interact with, and Node.js for the backend.

1.1. Web Application Development: Creating a web app for tracking cargo ships in real-time. <br>
1.2. Cargo Information Display: Showing details about what each ship is carrying and its current status. <br>
1.3. Map Visualization: Using a map to display the location of the ships, possibly with 3D features. <br>
1.4. Secure Access: Implementing a login system so only authorized users can access the app. <br>
1.5. API Integration: Using an external API to get real-time tracking data for the ships. <br>
1.6. Technology Stack: Developing the app with React (for the frontend) and Node.js (for the backend). <br>


Out of Scope
For our app we won't make any extra tools or apps that don't help with showing where cargo ships are and what they're carrying. We're not going to make the API ourselves—that's something we'll use but someone else has made. We're also not dealing with any of the computer servers or big machines that host our app; we're focusing just on the app itself. We won't be putting any gadgets on the ships to track them; we're assuming they're already being tracked by the API we use. Also, we're not making a version of our app for phones or using any super advanced tech like AI or machine learning to guess where ships will go next.

2.1. Ancillary Tool Development: Creating any tools or applications not directly related to tracking and visualizing cargo ship data.<br>
2.2. API Creation: Developing the tracking API ourselves.<br>
2.3. Infrastructure Provision: Managing servers or hosting infrastructure for the app.<br>
2.4. Hardware Interaction: Installing or maintaining tracking devices on cargo ships.<br>
2.5. Mobile App Development: Creating a mobile version of the application.<br>
2.6. Advanced Technology Implementation: Using artificial intelligence or machine learning for predictive analytics or data processing.<br>


## Capter 5: Deliverables 


Web Application: The primary deliverable is the fully functional web application itself, designed for tracking cargo ships in real-time. The application will allow users to view detailed information about the ships' cargo, including the type of cargo, its status, and the ship's current location on a map, potentially rendered in 3D for enhanced user experience.

User Authentication System: A secure login and authentication system to ensure that access to the application is restricted to authorized users. This system will protect sensitive information and ensure that the tracking data remains confidential.

API Integration Module: A module within the application responsible for integrating with an external tracking API. This module will fetch real-time data about the cargo ships' locations and status, which is crucial for the application's core functionality.

Documentation: Comprehensive documentation covering the application's design, functionality, user guide, and technical specifications. This will include a detailed description of how to use the application, as well as information for future developers on how to maintain and update the app.

Progress Reports: Periodic progress reports detailing the development process, challenges encountered, solutions implemented, and milestones achieved (PDR). These reports serve as a transparent communication tool between the project team and stakeholders.

Presentation: A final presentation to stakeholders that showcases the web application, its features, and its potential impact. This will provide an overview of the project's outcomes, the technology used, and the benefits it offers to users.


## Chapter 6: Quality

Our quality management plan is designed to ensure that the web application is reliable, secure, user-friendly, and meets CPL International’s specific needs and expectations.
We are going to be using ISO 9001:2015 for quality management system, ensuring that we meet customer and regulatory requirements efficiently. Also, the CE certification standard will be used so that we ensure EU safety, health, and environmental requirements.

For quality assurance, we will be using Github’s continuous integration and deployment by implementing tests and restrictions. Like not being able to push commits to main without passing the tests and without the pull request being approved. With these pull requests we are also applying quality control since to approve them, code reviews need to be done by at least one of the members of the group.

As for the roles, we will be having a scrum master that is going to be responsible of applying agile and scrum and keeping it up to date. Also, we will be having a project manager which is going to be responsible for the progression of the project and accountable for ensuring the quality of the project.
