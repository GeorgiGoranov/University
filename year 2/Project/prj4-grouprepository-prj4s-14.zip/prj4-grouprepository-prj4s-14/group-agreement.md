## Group expectations

- Our goal as a group is to score at least 8 
- That every group member is doing their tasks 
- All group members should aim to attend all group meetings and if that cannot be the case, they should inform all group members and continue to work on the project wherever they are based. 
- All group members should participate during project hours and work on a task 
- Another goal as a group is to have good communication between all members 
- Group members should help each other when asked. 
